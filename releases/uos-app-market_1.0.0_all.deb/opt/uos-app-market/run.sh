#!/usr/bin/env bash
set -e
cd /opt/uos-app-market
exec python3 main.py "$@"
