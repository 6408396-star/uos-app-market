#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""统信应用商城桌面客户端。"""

import base64
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import threading
import urllib.parse
import urllib.request
from pathlib import Path
from tkinter import (
    BOTH,
    DISABLED,
    END,
    LEFT,
    NORMAL,
    RIGHT,
    VERTICAL,
    X,
    Y,
    Button,
    Canvas,
    Entry,
    Frame,
    Label,
    Listbox,
    PhotoImage,
    Scrollbar,
    StringVar,
    Tk,
    messagebox,
)
from tkinter import ttk


APP_TITLE = "统信应用商城"
APP_VERSION = "1.0.0"
FONT = "Noto Sans CJK SC"
CATALOG_URL = "https://raw.githubusercontent.com/6408396-star/uos-app-market/main/apps.json"
WEB_STORE_URL = "https://6408396-star.github.io/uos-app-market/"
USER_AGENT = "uos-app-market/%s" % APP_VERSION
MAX_CATALOG_SIZE = 1024 * 1024

FOREST = "#214d3a"
FOREST_DARK = "#173a2b"
TEAL = "#137c72"
AMBER = "#e8ad45"
BG = "#f4f6f5"
SURFACE = "#ffffff"
MUTED = "#66716b"
LINE = "#dce2de"
INK = "#18201c"


def app_dir():
    return Path(__file__).resolve().parent


def local_catalog_path():
    return app_dir() / "apps.json"


def download_folder():
    preferred = Path.home() / "下载"
    if not preferred.exists():
        preferred = Path.home() / "Downloads"
    folder = preferred / APP_TITLE
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def read_local_catalog():
    return json.loads(local_catalog_path().read_text(encoding="utf-8"))


def fetch_catalog():
    request = urllib.request.Request(CATALOG_URL, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=10) as response:
        raw = response.read(MAX_CATALOG_SIZE + 1)
    if len(raw) > MAX_CATALOG_SIZE:
        raise ValueError("应用目录超过大小限制")
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("apps"), list):
        raise ValueError("应用目录格式无效")
    return data


def safe_package_name(value):
    name = Path(str(value or "application.deb")).name
    cleaned = "".join(char for char in name if char.isalnum() or char in "._-")
    return cleaned or "application.deb"


def is_https_url(value):
    try:
        parsed = urllib.parse.urlparse(str(value))
        return parsed.scheme == "https" and bool(parsed.netloc)
    except Exception:
        return False


def is_package_installed(package_id):
    if platform.system() != "Linux" or not package_id:
        return False
    try:
        result = subprocess.run(
            ["dpkg-query", "-W", "-f=${Status}", package_id],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=4,
            check=False,
        )
        return result.returncode == 0 and "install ok installed" in result.stdout
    except Exception:
        return False


class AppStore:
    def __init__(self, root):
        self.root = root
        self.root.title("%s %s" % (APP_TITLE, APP_VERSION))
        self.root.geometry("1160x760")
        self.root.minsize(900, 620)
        self.root.configure(bg=BG)

        self.apps = []
        self.category = "全部应用"
        self.search_var = StringVar()
        self.status_var = StringVar(value="正在读取应用目录...")
        self.progress_var = StringVar(value="0")
        self.images = []
        self.install_buttons = {}

        self.build_ui()
        self.search_var.trace_add("write", lambda *_args: self.render_apps())
        self.root.after(120, self.load_catalog)

    def build_ui(self):
        header = Frame(self.root, bg=FOREST_DARK, height=88)
        header.pack(fill=X)
        header.pack_propagate(False)

        logo = Label(
            header,
            text="U",
            font=("Georgia", 23, "bold"),
            fg="white",
            bg=FOREST,
            width=2,
            height=1,
        )
        logo.pack(side=LEFT, padx=(28, 12), pady=20)

        title_box = Frame(header, bg=FOREST_DARK)
        title_box.pack(side=LEFT, pady=17)
        Label(
            title_box,
            text=APP_TITLE,
            font=(FONT, 20, "bold"),
            fg="white",
            bg=FOREST_DARK,
        ).pack(anchor="w")
        Label(
            title_box,
            text="UOS APPLICATIONS  ·  v%s" % APP_VERSION,
            font=(FONT, 9),
            fg="#b9d3c6",
            bg=FOREST_DARK,
        ).pack(anchor="w")

        web_button = Button(
            header,
            text="打开网页商城",
            command=self.open_web_store,
            font=(FONT, 11, "bold"),
            fg="white",
            bg=TEAL,
            activebackground="#15978a",
            activeforeground="white",
            relief="flat",
            padx=18,
            pady=9,
            cursor="hand2",
        )
        web_button.pack(side=RIGHT, padx=(8, 28), pady=22)

        refresh_button = Button(
            header,
            text="刷新",
            command=self.load_catalog,
            font=(FONT, 11, "bold"),
            fg="#e7efe9",
            bg=FOREST_DARK,
            activebackground=FOREST,
            activeforeground="white",
            relief="solid",
            bd=1,
            padx=16,
            pady=8,
            cursor="hand2",
        )
        refresh_button.pack(side=RIGHT, pady=22)

        search_wrap = Frame(self.root, bg=SURFACE, highlightbackground=LINE, highlightthickness=1)
        search_wrap.pack(fill=X, padx=28, pady=(22, 14))
        Label(search_wrap, text="搜索", font=(FONT, 11, "bold"), fg=MUTED, bg=SURFACE).pack(
            side=LEFT, padx=(16, 10), pady=12
        )
        self.search_entry = Entry(
            search_wrap,
            textvariable=self.search_var,
            font=(FONT, 12),
            fg=INK,
            bg=SURFACE,
            relief="flat",
            insertbackground=INK,
        )
        self.search_entry.pack(side=LEFT, fill=X, expand=True, padx=(0, 16), pady=12)

        content = Frame(self.root, bg=BG)
        content.pack(fill=BOTH, expand=True, padx=28, pady=(0, 16))

        sidebar = Frame(content, bg=BG, width=190)
        sidebar.pack(side=LEFT, fill=Y, padx=(0, 18))
        sidebar.pack_propagate(False)
        Label(
            sidebar,
            text="应用分类",
            font=(FONT, 12, "bold"),
            fg=INK,
            bg=BG,
            anchor="w",
        ).pack(fill=X, pady=(4, 10))

        self.category_list = Listbox(
            sidebar,
            font=(FONT, 11),
            fg=INK,
            bg=BG,
            selectforeground=FOREST_DARK,
            selectbackground="#e3eee8",
            activestyle="none",
            relief="flat",
            highlightthickness=0,
            exportselection=False,
        )
        self.category_list.pack(fill=X)
        self.category_list.bind("<<ListboxSelect>>", self.on_category_change)

        source_box = Frame(sidebar, bg="#e8f0eb", highlightbackground="#c7d8ce", highlightthickness=1)
        source_box.pack(side="bottom", fill=X, pady=(12, 0))
        Label(source_box, text="●", font=(FONT, 10), fg="#2c9b67", bg="#e8f0eb").pack(
            side=LEFT, padx=(12, 6), pady=12
        )
        source_text = Frame(source_box, bg="#e8f0eb")
        source_text.pack(side=LEFT, pady=9)
        Label(source_text, text="在线应用源", font=(FONT, 10, "bold"), fg=INK, bg="#e8f0eb").pack(
            anchor="w"
        )
        Label(source_text, text="自动获取最新版", font=(FONT, 8), fg=MUTED, bg="#e8f0eb").pack(anchor="w")

        app_area = Frame(content, bg=BG)
        app_area.pack(side=LEFT, fill=BOTH, expand=True)

        section_head = Frame(app_area, bg=BG)
        section_head.pack(fill=X, pady=(0, 10))
        self.section_title = Label(
            section_head,
            text="全部应用",
            font=(FONT, 18, "bold"),
            fg=INK,
            bg=BG,
        )
        self.section_title.pack(side=LEFT)
        self.result_label = Label(section_head, text="", font=(FONT, 10), fg=MUTED, bg=BG)
        self.result_label.pack(side=RIGHT, pady=6)

        canvas_wrap = Frame(app_area, bg=BG)
        canvas_wrap.pack(fill=BOTH, expand=True)
        self.canvas = Canvas(canvas_wrap, bg=BG, highlightthickness=0)
        scrollbar = Scrollbar(canvas_wrap, orient=VERTICAL, command=self.canvas.yview)
        self.card_container = Frame(self.canvas, bg=BG)
        self.card_window = self.canvas.create_window((0, 0), window=self.card_container, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.pack(side=RIGHT, fill=Y)
        self.card_container.bind("<Configure>", self.update_scroll_region)
        self.canvas.bind("<Configure>", self.resize_card_container)
        self.canvas.bind_all("<MouseWheel>", self.on_mousewheel)

        status_bar = Frame(self.root, bg=SURFACE, highlightbackground=LINE, highlightthickness=1)
        status_bar.pack(side="bottom", fill=X)
        self.status_label = Label(
            status_bar,
            textvariable=self.status_var,
            font=(FONT, 9),
            fg=MUTED,
            bg=SURFACE,
            anchor="w",
        )
        self.status_label.pack(side=LEFT, fill=X, expand=True, padx=18, pady=9)
        self.progress = ttk.Progressbar(status_bar, length=170, mode="determinate", maximum=100)
        self.progress.pack(side=RIGHT, padx=18, pady=10)

    def update_scroll_region(self, _event=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def resize_card_container(self, event):
        self.canvas.itemconfigure(self.card_window, width=event.width)

    def on_mousewheel(self, event):
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def set_status(self, text, progress=None):
        self.status_var.set(text)
        if progress is not None:
            self.progress["value"] = max(0, min(100, progress))

    def load_catalog(self):
        self.set_status("正在连接在线应用源...", 0)

        def worker():
            try:
                data = fetch_catalog()
                source = "在线应用源"
            except Exception:
                data = read_local_catalog()
                source = "离线应用目录"
            self.root.after(0, lambda: self.apply_catalog(data, source))

        threading.Thread(target=worker, daemon=True).start()

    def apply_catalog(self, data, source):
        self.apps = list(data.get("apps") or [])
        categories = ["全部应用"]
        for app in self.apps:
            category = str(app.get("category") or "其他")
            if category not in categories:
                categories.append(category)
        self.category_list.delete(0, END)
        for category in categories:
            self.category_list.insert(END, category)
        self.category_list.selection_set(0)
        self.category = "全部应用"
        self.render_apps()
        self.set_status("%s已更新，共 %d 个应用" % (source, len(self.apps)), 100)

    def on_category_change(self, _event=None):
        selection = self.category_list.curselection()
        if not selection:
            return
        self.category = self.category_list.get(selection[0])
        self.render_apps()

    def filtered_apps(self):
        query = self.search_var.get().strip().lower()
        result = []
        for app in self.apps:
            category = str(app.get("category") or "其他")
            if self.category != "全部应用" and category != self.category:
                continue
            searchable = " ".join(
                str(app.get(key) or "") for key in ("name", "category", "summary", "developer")
            ).lower()
            if query and query not in searchable:
                continue
            result.append(app)
        return result

    def render_apps(self):
        for child in self.card_container.winfo_children():
            child.destroy()
        self.images.clear()
        self.install_buttons.clear()
        apps = self.filtered_apps()
        self.section_title.configure(text=self.category)
        self.result_label.configure(text="%d 个应用" % len(apps))

        if not apps:
            empty = Frame(self.card_container, bg=SURFACE, highlightbackground=LINE, highlightthickness=1)
            empty.pack(fill=X, pady=4)
            Label(
                empty,
                text="没有找到应用",
                font=(FONT, 14, "bold"),
                fg=INK,
                bg=SURFACE,
            ).pack(pady=(46, 8))
            Label(empty, text="请更换搜索内容或应用分类", font=(FONT, 10), fg=MUTED, bg=SURFACE).pack(
                pady=(0, 46)
            )
            return

        for app in apps:
            self.render_card(app)

    def load_local_icon(self, app):
        candidates = []
        icon_path = str(app.get("icon") or "")
        if icon_path and not urllib.parse.urlparse(icon_path).scheme:
            candidates.append(app_dir() / icon_path)
        candidates.append(app_dir() / "assets" / "store-icon.png")
        for path in candidates:
            try:
                if path.exists():
                    data = base64.b64encode(path.read_bytes()).decode("ascii")
                    return PhotoImage(data=data).subsample(4, 4)
            except Exception:
                pass
        return None

    def render_card(self, app):
        card = Frame(self.card_container, bg=SURFACE, highlightbackground=LINE, highlightthickness=1)
        card.pack(fill=X, pady=5, padx=1)

        icon = self.load_local_icon(app)
        if icon:
            self.images.append(icon)
            Label(card, image=icon, bg=SURFACE).pack(side=LEFT, padx=18, pady=18)
        else:
            Label(
                card,
                text="U",
                font=("Georgia", 24, "bold"),
                fg="white",
                bg=FOREST,
                width=3,
                height=2,
            ).pack(side=LEFT, padx=18, pady=18)

        info = Frame(card, bg=SURFACE)
        info.pack(side=LEFT, fill=BOTH, expand=True, pady=15)
        Label(
            info,
            text=str(app.get("name") or "未命名应用"),
            font=(FONT, 15, "bold"),
            fg=INK,
            bg=SURFACE,
            anchor="w",
        ).pack(fill=X)
        Label(
            info,
            text="%s  ·  %s" % (app.get("category") or "其他", app.get("developer") or "未知开发者"),
            font=(FONT, 9),
            fg=MUTED,
            bg=SURFACE,
            anchor="w",
        ).pack(fill=X, pady=(2, 8))
        Label(
            info,
            text=str(app.get("summary") or ""),
            font=(FONT, 10),
            fg="#4c5852",
            bg=SURFACE,
            anchor="w",
            justify=LEFT,
            wraplength=570,
        ).pack(fill=X)
        Label(
            info,
            text="v%s  ·  %s  ·  %s" % (
                app.get("version") or "-",
                app.get("architecture") or "-",
                app.get("size") or "-",
            ),
            font=(FONT, 9),
            fg=TEAL,
            bg=SURFACE,
            anchor="w",
        ).pack(fill=X, pady=(9, 0))

        actions = Frame(card, bg=SURFACE)
        actions.pack(side=RIGHT, padx=18, pady=18)
        Button(
            actions,
            text="详情",
            command=lambda current=app: self.show_details(current),
            font=(FONT, 10, "bold"),
            fg=INK,
            bg=SURFACE,
            activebackground="#eef1ef",
            relief="solid",
            bd=1,
            padx=15,
            pady=7,
            cursor="hand2",
        ).pack(side=LEFT, padx=(0, 8))

        installed = is_package_installed(str(app.get("packageId") or ""))
        button = Button(
            actions,
            text="已安装" if installed else "安装",
            command=lambda current=app: self.install_app(current),
            font=(FONT, 10, "bold"),
            fg="#231c0e",
            bg=AMBER,
            activebackground="#f0bd63",
            relief="flat",
            padx=20,
            pady=8,
            cursor="arrow" if installed else "hand2",
            state=DISABLED if installed else NORMAL,
        )
        button.pack(side=LEFT)
        self.install_buttons[str(app.get("id") or "")] = button

    def show_details(self, app):
        features = app.get("features") or []
        text = str(app.get("description") or app.get("summary") or "")
        if features:
            text += "\n\n" + "\n".join("• %s" % feature for feature in features)
        text += "\n\n版本：%s\n安装包：%s\n适用系统：%s" % (
            app.get("version") or "-",
            app.get("packageName") or "-",
            app.get("compatibility") or "统信 UOS",
        )
        messagebox.showinfo(str(app.get("name") or APP_TITLE), text, parent=self.root)

    def install_app(self, app):
        if platform.system() != "Linux":
            messagebox.showinfo(APP_TITLE, "一键安装仅在统信 UOS / Linux 系统中可用。", parent=self.root)
            return
        url = str(app.get("downloadUrl") or "")
        if not is_https_url(url):
            messagebox.showerror(APP_TITLE, "安装包下载地址无效，只允许 HTTPS 地址。", parent=self.root)
            return

        package_name = safe_package_name(app.get("packageName"))
        destination = download_folder() / package_name
        button = self.install_buttons.get(str(app.get("id") or ""))
        if button:
            button.configure(text="下载中", state=DISABLED)
        self.set_status("正在下载 %s..." % app.get("name"), 0)

        def worker():
            try:
                self.download_package(app, url, destination)
                self.root.after(0, lambda: self.launch_installer(app, destination))
            except Exception as exc:
                self.root.after(0, lambda: self.install_failed(app, str(exc)))

        threading.Thread(target=worker, daemon=True).start()

    def download_package(self, app, url, destination):
        part = destination.with_suffix(destination.suffix + ".part")
        request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        digest = hashlib.sha256()
        try:
            with urllib.request.urlopen(request, timeout=30) as response, part.open("wb") as output:
                total = int(response.headers.get("Content-Length") or 0)
                received = 0
                while True:
                    chunk = response.read(64 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
                    digest.update(chunk)
                    received += len(chunk)
                    if total:
                        progress = int(received * 100 / total)
                        self.root.after(0, lambda value=progress: self.progress.configure(value=value))
            expected = str(app.get("sha256") or "").strip().upper()
            actual = digest.hexdigest().upper()
            if expected and expected != actual:
                raise ValueError("安装包校验失败，请重新下载")
            part.replace(destination)
        except Exception:
            try:
                if part.exists():
                    part.unlink()
            except Exception:
                pass
            raise

    def launch_installer(self, app, package_path):
        self.set_status("下载完成，正在打开系统软件包安装器...", 100)
        launchers = (
            ("deepin-deb-installer", [str(package_path)]),
            ("gdebi-gtk", [str(package_path)]),
            ("xdg-open", [str(package_path)]),
        )
        for command, arguments in launchers:
            executable = shutil.which(command)
            if not executable:
                continue
            try:
                subprocess.Popen([executable, *arguments])
                self.reset_install_button(app, "安装")
                messagebox.showinfo(
                    APP_TITLE,
                    "安装包已下载并打开系统安装器。\n\n请在系统窗口中点击《安装》，按提示完成一次管理员授权。",
                    parent=self.root,
                )
                return
            except Exception:
                continue

        self.reset_install_button(app, "安装")
        command = "sudo apt install ./%s" % package_path.name
        messagebox.showinfo(
            APP_TITLE,
            "安装包已保存到：\n%s\n\n请在该目录打开终端并执行：\n%s" % (package_path.parent, command),
            parent=self.root,
        )

    def install_failed(self, app, error):
        self.set_status("下载失败：%s" % error, 0)
        self.reset_install_button(app, "重试")
        messagebox.showerror(APP_TITLE, "下载或校验失败：\n%s" % error, parent=self.root)

    def reset_install_button(self, app, text):
        button = self.install_buttons.get(str(app.get("id") or ""))
        if button:
            button.configure(text=text, state=NORMAL)

    def open_web_store(self):
        try:
            if platform.system() == "Windows":
                os.startfile(WEB_STORE_URL)
            else:
                subprocess.Popen(["xdg-open", WEB_STORE_URL])
        except Exception as exc:
            messagebox.showerror(APP_TITLE, "无法打开网页商城：%s" % exc, parent=self.root)


def self_test():
    data = read_local_catalog()
    apps = data.get("apps")
    if not isinstance(apps, list) or not apps:
        raise ValueError("本地应用目录为空")
    for app in apps:
        for field in ("id", "name", "version", "packageName", "downloadUrl", "sha256"):
            if not app.get(field):
                raise ValueError("应用 %s 缺少字段 %s" % (app.get("name") or "未知", field))
        if not is_https_url(app["downloadUrl"]):
            raise ValueError("应用下载地址不是 HTTPS：%s" % app["name"])
        if len(str(app["sha256"])) != 64:
            raise ValueError("应用 SHA256 长度错误：%s" % app["name"])
    print("SELF_TEST_OK")
    print("Version:", APP_VERSION)
    print("Applications:", len(apps))


def main():
    if "--self-test" in sys.argv:
        self_test()
        return
    root = Tk()
    AppStore(root)
    root.mainloop()


if __name__ == "__main__":
    main()
